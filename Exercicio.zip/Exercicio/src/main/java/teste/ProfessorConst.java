
package teste;


public class ProfessorConst {

    public static String Chris =
            "{ \"nome\": \"Chris\", \n " +
                    "\"horario_atendimento\": \"16 horas\", \n " +
                    "\"periodo\": \"Integral\" }";

    public static String Renzo =
            "{ \"nome\": \"Renzo\", \n " +
                    "\"horario_atendimento\": \"14 horas\", \n " +
                    "\"periodo\": \"Integral\" }";
    
    public static String Marcelo =
            "{ \"nome\": \"Marcelo\", \n " +
                    "\"horario_atendimento\": \"15 horas\", \n " +
                    "\"periodo\": \"Integral\" }";

    public static String INEXISTENTE =
            "{ \"nome\": \"Inexistente\", \n " +
                    "\"horario_atendimento\": \"Inexistente\",\n " +
                    "\"periodo\": \"Inexistente\" }";


}

