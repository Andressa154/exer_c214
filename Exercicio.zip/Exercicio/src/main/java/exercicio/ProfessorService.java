
package exercicio;

public interface ProfessorService {
    
     public String busca(int id);

}